﻿using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using System;
using System.IO;
using UnityEngine;


namespace HolyMod
{
    [BepInPlugin("com.holypotatoes.weaponshop.modloader", "Holy Potatoes Mod Loader", "1.0.0")]
    public class HolyModPlugin : BaseUnityPlugin
    {
        internal static ManualLogSource Log;

        private void Awake()
        {
            // Initialize logging
            Log = base.Logger;
            Log.LogInfo("Holy Potatoes Mod Loader starting...");

            try
            {
                // Initialize mod manager
                string modsPath = Path.Combine(Paths.GameRootPath, "Mods");
                bool enableDebugLogs = Config.Bind("Logging", "EnableDebug", false, "Enable debug logging").Value;

                ModManager.Initialize(modsPath, enableDebugLogs);
                
                // Initialize Harmony patches
                HolyModLoader.Initialize();
                
                Log.LogInfo("Holy Potatoes Mod Loader initialized successfully");
            }
            catch (Exception ex)
            {
                Log.LogError($"Failed to initialize mod loader: {ex}");
            }
        }
    }
}