﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using UnityEngine;
using BepInEx.Logging;
using HarmonyLib;
using System.Collections;

namespace HolyMod
{
    [Serializable]
    public class ModInfo
    {
        public string id;
        public string name;
        public string version;
        public string author;
        public string description;
    }

    [Serializable]
    public class MaterialEntry
    {
        public string key;
        public int value;
    }

    [Serializable]
    public class ModWeapon
    {
        public string weaponRefId;
        public string weaponName;
        public string weaponDesc;
        public string image;
        public string weaponType;
        public float atkMult;
        public float spdMult;
        public float accMult;
        public float magMult;
        public string researchType;
        public int researchDuration;
        public int researchCost;
        public int researchMood;
        public int dlc;
        public string scenarioLock;
        public string[] materials;
        public string[] relics;

        public Dictionary<string, int> GetMaterialDictionary()
        {
            Dictionary<string, int> result = new Dictionary<string, int>();
            if (materials != null)
            {
                foreach (string material in materials)
                {
                    string[] parts = material.Split(':');
                    if (parts.Length == 2)
                    {
                        int value;
                        if (int.TryParse(parts[1], out value))
                        {
                            result[parts[0]] = value;
                        }
                    }
                }
            }
            return result;
        }

        public Weapon ToGameWeapon()
        {
            try
            {
                if (string.IsNullOrEmpty(weaponRefId))
                {
                    throw new ArgumentException("weaponRefId cannot be null or empty");
                }

                if (string.IsNullOrEmpty(weaponType))
                {
                    throw new ArgumentException("weaponType cannot be null or empty");
                }

                var materialList = GetMaterialDictionary();
                if (materialList == null || materialList.Count == 0)
                {
                    HolyModPlugin.Log.LogWarning($"No materials defined for weapon {weaponName}");
                    materialList = new Dictionary<string, int>();
                }

                var relicList = relics != null ? new List<string>(relics) : new List<string>();

                WeaponStat researchTypeStat;
                switch (researchType.ToUpper())
                {
                    case "ATTACK":
                        researchTypeStat = WeaponStat.WeaponStatAttack;
                        break;
                    case "SPEED":
                        researchTypeStat = WeaponStat.WeaponStatSpeed;
                        break;
                    case "ACCURACY":
                        researchTypeStat = WeaponStat.WeaponStatAccuracy;
                        break;
                    case "MAGIC":
                        researchTypeStat = WeaponStat.WeaponStatMagic;
                        break;
                    default:
                        HolyModPlugin.Log.LogWarning($"Invalid research type '{researchType}' for weapon {weaponName}, defaulting to Attack");
                        researchTypeStat = WeaponStat.WeaponStatAttack;
                        break;
                }

                HolyModPlugin.Log.LogDebug($"Creating weapon with type {weaponType}");
                var weapon = new Weapon(
                    weaponRefId,
                    weaponName ?? "Unknown Weapon",
                    weaponDesc ?? "",
                    image ?? weaponRefId,
                    weaponType,
                    atkMult,
                    spdMult,
                    accMult,
                    magMult,
                    materialList,
                    relicList,
                    researchTypeStat,
                    researchDuration,
                    researchCost,
                    researchMood,
                    dlc,
                    scenarioLock ?? ""
                );

                if (weapon == null)
                {
                    throw new InvalidOperationException($"Failed to create Weapon instance for {weaponName}");
                }

                return weapon;
            }
            catch (Exception ex)
            {
                HolyModPlugin.Log.LogError($"Failed to convert mod weapon {weaponName} to game weapon: {ex}");
                throw;
            }
        }
    }

    [Serializable]
    public class ModWeapons
    {
        [SerializeField]
        public ModWeapon[] weaponsList;

        public List<ModWeapon> GetWeapons()
        {
            return weaponsList != null ? new List<ModWeapon>(weaponsList) : new List<ModWeapon>();
        }
    }

    [Serializable]
    public class JsonWrapper<T>
    {
        public T data;

        public static T Unwrap(string json)
        {
            try
            {
                // Try direct parse first
                T result = JsonUtility.FromJson<T>(json);
                if (result != null)
                {
                    HolyModPlugin.Log.LogDebug("Direct parse in wrapper succeeded");
                    return result;
                }

                // If that fails, try wrapping
                string wrappedJson = "{ \"data\": " + json + "}";
                HolyModPlugin.Log.LogDebug($"Attempting wrapped parse with: {wrappedJson}");
                var wrapper = JsonUtility.FromJson<JsonWrapper<T>>(wrappedJson);
                
                if (wrapper == null)
                {
                    HolyModPlugin.Log.LogError("Wrapper parse resulted in null wrapper");
                    return default(T);
                }
                
                if (wrapper.data == null)
                {
                    HolyModPlugin.Log.LogError("Wrapper parse resulted in null data");
                    return default(T);
                }

                HolyModPlugin.Log.LogDebug("Wrapper parse succeeded");
                return wrapper.data;
            }
            catch (Exception ex)
            {
                HolyModPlugin.Log.LogError($"Error in JsonWrapper.Unwrap: {ex.Message}");
                throw;
            }
        }
    }

    public class ModManager
    {
        private static ModManager instance;
        private readonly bool enableDebugLogs;
        private readonly Dictionary<string, ModInfo> loadedMods;
        private readonly List<ModWeapon> customWeapons;
        private string modsDirectory;

        public static ModManager Instance
        {
            get
            {
                if (instance == null)
                {
                    throw new InvalidOperationException("ModManager not initialized");
                }
                return instance;
            }
        }

        public bool IsDebugLoggingEnabled => enableDebugLogs;
        public string ModsDirectory => modsDirectory;
        public Dictionary<string, ModInfo> LoadedMods => loadedMods;
        public List<ModWeapon> CustomWeapons => customWeapons;

        private ModManager(string modsDir, bool debug)
        {
            modsDirectory = modsDir;
            enableDebugLogs = debug;
            loadedMods = new Dictionary<string, ModInfo>();
            customWeapons = new List<ModWeapon>();
            LoadMods();
        }

        public static void Initialize(string modsDir, bool debugLogs)
        {
            if (instance != null)
            {
                throw new InvalidOperationException("ModManager already initialized");
            }
            
            instance = new ModManager(modsDir, debugLogs);
            
            if (instance.IsDebugLoggingEnabled)
                HolyModPlugin.Log.LogDebug($"ModManager initialized with mods directory: {instance.ModsDirectory}");
        }

        private List<ModWeapon> LoadWeaponsFromDirectory(string modDirectory)
        {
            var weaponsDir = Path.Combine(modDirectory, "weapons");
            var weapons = new List<ModWeapon>();
            
            if (!Directory.Exists(weaponsDir))
            {
                HolyModPlugin.Log.LogWarning($"No weapons directory found in {modDirectory}");
                return weapons;
            }

            foreach (var file in Directory.GetFiles(weaponsDir, "*.json"))
            {
                try
                {
                    var json = File.ReadAllText(file);
                    var weapon = JsonUtility.FromJson<ModWeapon>(json);
                    
                    if (weapon != null)
                    {
                        if (IsDebugLoggingEnabled)
                        {
                            HolyModPlugin.Log.LogDebug($"Loaded weapon: {weapon.weaponName} from {Path.GetFileName(file)}");
                        }
                        weapons.Add(weapon);
                    }
                    else
                    {
                        HolyModPlugin.Log.LogError($"Failed to parse weapon from {Path.GetFileName(file)}");
                    }
                }
                catch (Exception ex)
                {
                    HolyModPlugin.Log.LogError($"Error loading weapon from {Path.GetFileName(file)}: {ex.Message}");
                }
            }

            return weapons;
        }

        public void LoadMods()
        {
            if (!Directory.Exists(ModsDirectory))
            {
                HolyModPlugin.Log.LogWarning($"Mods directory not found: {ModsDirectory}");
                return;
            }

            HolyModPlugin.Log.LogInfo($"Searching for mods in directory: {ModsDirectory}");
            var modDirs = Directory.GetDirectories(ModsDirectory);
            HolyModPlugin.Log.LogInfo($"Found {modDirs.Length} directories in mods folder");

            foreach (var modDir in modDirs)
            {
                HolyModPlugin.Log.LogInfo($"Checking mod directory: {modDir}");
                var manifestPath = Path.Combine(modDir, "manifest.json");
                
                var manifestExists = File.Exists(manifestPath);
                HolyModPlugin.Log.LogInfo($"  Manifest exists: {manifestExists}");

                if (!manifestExists)
                {
                    HolyModPlugin.Log.LogWarning($"  Skipping directory {modDir} - missing manifest.json");
                    continue;
                }

                try
                {
                    var manifestJson = File.ReadAllText(manifestPath);
                    if (IsDebugLoggingEnabled)
                    {
                        HolyModPlugin.Log.LogDebug($"  Manifest content: {manifestJson}");
                    }

                    var modInfo = JsonUtility.FromJson<ModInfo>(manifestJson);
                    if (modInfo == null)
                    {
                        HolyModPlugin.Log.LogError($"  Failed to parse manifest.json in {modDir}");
                        continue;
                    }

                    HolyModPlugin.Log.LogInfo($"  Loading mod: {modInfo.name} v{modInfo.version}");
                    
                    var weapons = LoadWeaponsFromDirectory(modDir);
                    if (weapons.Count > 0)
                    {
                        loadedMods[modInfo.id] = modInfo;
                        foreach (var weapon in weapons)
                        {
                            customWeapons.Add(weapon);
                        }
                        HolyModPlugin.Log.LogInfo($"  Loaded {weapons.Count} weapons from {modInfo.name}");
                    }
                    else
                    {
                        HolyModPlugin.Log.LogWarning($"  No weapons found in {modInfo.name}");
                    }
                }
                catch (Exception ex)
                {
                    HolyModPlugin.Log.LogError($"  Error loading mod from {modDir}: {ex.Message}");
                }
            }

            HolyModPlugin.Log.LogInfo($"Mod loading completed. Loaded {loadedMods.Count} mods with {customWeapons.Count} total weapons");
        }

        public void InjectModdedWeapons(GameData gameData)
        {
            if (gameData == null)
            {
                HolyModPlugin.Log.LogError("GameData is null in InjectModdedWeapons");
                return;
            }

            try
            {
                // First ensure weapon types exist
                EnsureWeaponTypes(gameData);

                var weaponTypes = gameData.getWeaponTypeList();
                HolyModPlugin.Log.LogInfo($"Found {weaponTypes.Count} weapon types in game data");

                // Then add weapons
                foreach (var weapon in CustomWeapons)
                {
                    try 
                    {
                        // Find weapon type by exact match
                        WeaponType weaponType = null;
                        foreach (var type in weaponTypes)
                        {
                            if (type.getWeaponTypeRefId().Equals(weapon.weaponType, StringComparison.OrdinalIgnoreCase))
                            {
                                weaponType = type;
                                break;
                            }
                        }

                        if (weaponType == null)
                        {
                            HolyModPlugin.Log.LogWarning($"Weapon type '{weapon.weaponType}' not found for weapon '{weapon.weaponName}', available types: {string.Join(", ", weaponTypes.Select(t => t.getWeaponTypeRefId()).ToArray())}");
                            continue;
                        }

                        // Convert materials string array to dictionary
                        Dictionary<string, int> materials = new Dictionary<string, int>();
                        if (weapon.materials != null)
                        {
                            foreach (string matEntry in weapon.materials)
                            {
                                string[] parts = matEntry.Split(':');
                                if (parts.Length == 2 && int.TryParse(parts[1], out int count))
                                {
                                    materials[parts[0]] = count;
                                }
                                else
                                {
                                    HolyModPlugin.Log.LogWarning($"Invalid material format in weapon {weapon.weaponName}: {matEntry}");
                                }
                            }
                        }

                        // Parse research type
                        WeaponStat researchTypeStat;
                        switch (weapon.researchType.ToUpper())
                        {
                            case "ATTACK":
                                researchTypeStat = WeaponStat.WeaponStatAttack;
                                break;
                            case "SPEED":
                                researchTypeStat = WeaponStat.WeaponStatSpeed;
                                break;
                            case "ACCURACY":
                                researchTypeStat = WeaponStat.WeaponStatAccuracy;
                                break;
                            case "MAGIC":
                                researchTypeStat = WeaponStat.WeaponStatMagic;
                                break;
                            default:
                                HolyModPlugin.Log.LogWarning($"Invalid research type '{weapon.researchType}' for weapon '{weapon.weaponName}', defaulting to Attack");
                                researchTypeStat = WeaponStat.WeaponStatAttack;
                                break;
                        }

                        // Add the weapon
                        // Ensure weapon ID is numeric - use a base number plus an index
                        int baseId = 10000; // Start custom weapons at ID 10000
                        int weaponIndex = CustomWeapons.IndexOf(weapon) + 1;
                        string numericWeaponId = (baseId + weaponIndex).ToString();

                        gameData.addWeapon(
                            numericWeaponId, // Use numeric ID
                            weapon.weaponName ?? "Unknown Weapon",
                            weapon.weaponDesc ?? "",
                            weapon.image ?? weapon.weaponRefId,
                            weaponType.getWeaponTypeRefId(),
                            weapon.atkMult,
                            weapon.spdMult,
                            weapon.accMult,
                            weapon.magMult,
                            materials,
                            weapon.relics != null ? new List<string>(weapon.relics) : new List<string>(),
                            researchTypeStat,
                            weapon.researchDuration,
                            weapon.researchCost,
                            weapon.researchMood,
                            weapon.dlc,
                            weapon.scenarioLock ?? ""
                        );

                        // Get the added weapon and unlock it
                        var addedWeapon = gameData.getWeaponByRefId(numericWeaponId);
                        if (addedWeapon != null)
                        {
                            // Unlock both the weapon type and the weapon
                            weaponType.doUnlock();
                            addedWeapon.setWeaponUnlocked(true);
                            
                            // Get player instance directly from scene
                            var game = GameObject.Find("Game")?.GetComponent<Game>();
                            var player = game?.getPlayer();
                            if (player != null)
                            {
                                // Add to player's unlocked lists
                                player.unlockWeapon(addedWeapon);
                                player.unlockWeaponType(weaponType);
                            }
                            else
                            {
                                HolyModPlugin.Log.LogWarning($"Could not get player instance to unlock weapon {weapon.weaponName}");
                            }
                        }

                        HolyModPlugin.Log.LogInfo($"Added modded weapon: {weapon.weaponName} of type {weaponType.getWeaponTypeRefId()}");
                    }
                    catch (Exception ex)
                    {
                        HolyModPlugin.Log.LogError($"Failed to add weapon {weapon.weaponName}: {ex}");
                    }
                }
            }
            catch (Exception ex)
            {
                HolyModPlugin.Log.LogError($"Error in InjectModdedWeapons: {ex}");
            }
        }

        private void EnsureWeaponTypes(GameData gameData)
        {
            try
            {
                var existingTypes = gameData.getWeaponTypeList();
                HolyModPlugin.Log.LogInfo($"Current weapon types: {existingTypes.Count}");

                // Map our weapon types to game's weapon type IDs
                var weaponTypeMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                {
                    // Basic weapon types (100 series)
                    { "SWORD", "101" },
                    { "DAGGER", "102" },
                    { "AXE", "103" },
                    { "SPEAR", "104" },
                    
                    // Ranged weapon types (200 series)
                    { "BOW", "201" },
                    { "CROSSBOW", "202" },
                    { "GUN", "203" },
                    { "THROWING", "204" },
                    { "WHIP", "205" },
                    
                    // Magic/Special weapon types (300 series)
                    { "STAFF", "301" },
                    { "WAND", "302" },
                    { "ORB", "303" },
                    
                    // Special types
                    { "LEGENDARY", "901" }
                };

                // Update weapon types in our custom weapons
                foreach (var weapon in CustomWeapons)
                {
                    if (weaponTypeMap.TryGetValue(weapon.weaponType, out string gameTypeId))
                    {
                        weapon.weaponType = gameTypeId;
                        HolyModPlugin.Log.LogInfo($"Mapped weapon type for {weapon.weaponName}: {gameTypeId}");
                    }
                    else
                    {
                        HolyModPlugin.Log.LogWarning($"No mapping found for weapon type {weapon.weaponType} on weapon {weapon.weaponName}. Available types: {string.Join(", ", weaponTypeMap.Keys.ToArray())}");
                    }

                    // Also update research type to match game's enum
                    switch (weapon.researchType.ToUpper())
                    {
                        case "DESIGN":
                        case "ATTACK":
                        case "ATK":
                            weapon.researchType = "ATTACK";
                            break;
                        case "CRAFT":
                        case "SPEED":
                        case "SPD":
                            weapon.researchType = "SPEED";
                            break;
                        case "POLISH":
                        case "ACCURACY":
                        case "ACC":
                            weapon.researchType = "ACCURACY";
                            break;
                        case "ENCHANT":
                        case "MAGIC":
                        case "MAG":
                            weapon.researchType = "MAGIC";
                            break;
                        default:
                            HolyModPlugin.Log.LogWarning($"Unknown research type '{weapon.researchType}' for weapon '{weapon.weaponName}', defaulting to ATTACK");
                            weapon.researchType = "ATTACK";
                            break;
                    }
                }

                if (existingTypes.Count > 0)
                {
                    HolyModPlugin.Log.LogInfo($"Using existing weapon types: {string.Join(", ", existingTypes.Select(t => t.getWeaponTypeRefId()).ToArray())}");
                }
            }
            catch (Exception ex)
            {
                HolyModPlugin.Log.LogError($"Error in EnsureWeaponTypes: {ex}");
            }
        }

        public Game GetGameInstance(GameData gameData)
        {
            try
            {
                // Use reflection to get the private game field from GameData
                var gameField = typeof(GameData).GetField("game", 
                    System.Reflection.BindingFlags.NonPublic | 
                    System.Reflection.BindingFlags.Instance);
                
                if (gameField == null)
                {
                    HolyModPlugin.Log.LogError("Could not find 'game' field in GameData");
                    return null;
                }

                return gameField.GetValue(gameData) as Game;
            }
            catch (Exception ex)
            {
                HolyModPlugin.Log.LogError($"Error getting Game instance: {ex}");
                return null;
            }
        }

        public bool IsCustomWeapon(string weaponRefId)
        {
            // Check if the ID is in our custom weapon range (10000+)
            if (int.TryParse(weaponRefId, out int id))
            {
                return id >= 10000;
            }
            return false;
        }

        public string GetModTexturePath(string textureName)
        {
            foreach (string modDir in Directory.GetDirectories(ModsDirectory))
            {
                string assetsPath = Path.Combine(modDir, "assets");
                string texturesPath = Path.Combine(assetsPath, "textures");
                string weaponsPath = Path.Combine(texturesPath, "weapons");
                string texturePath = Path.Combine(weaponsPath, textureName + ".png");

                if (File.Exists(texturePath))
                {
                    if (IsDebugLoggingEnabled)
                        HolyModPlugin.Log.LogDebug($"Found texture for {textureName} at {texturePath}");
                    return texturePath;
                }
            }
            
            HolyModPlugin.Log.LogWarning($"Could not find texture for {textureName}");
            return null;
        }
    }

    [HarmonyPatch(typeof(ViewController))]
    public class ViewControllerPatches
    {
        [HarmonyPatch("showStartScreen")]
        [HarmonyPostfix]
        public static void ShowStartScreen_Postfix()
        {
            if (ModManager.Instance.IsDebugLoggingEnabled)
                HolyModPlugin.Log.LogDebug("ViewController.showStartScreen patched");
        }
    }

    [HarmonyPatch(typeof(RefDataController))]
    public class RefDataControllerPatches
    {
        [HarmonyPatch("processAllRefData")]
        [HarmonyPostfix]
        public static void ProcessAllRefData_Postfix(RefDataController __instance, ServerValue aValue)
        {
            try
            {
                if (__instance == null)
                {
                    HolyModPlugin.Log.LogError("RefDataController instance is null");
                    return;
                }

                // Get GameData first
                var gameField = typeof(RefDataController).GetField("game", 
                    System.Reflection.BindingFlags.NonPublic | 
                    System.Reflection.BindingFlags.Instance);
                
                if (gameField == null)
                {
                    HolyModPlugin.Log.LogError("Could not find 'game' field in RefDataController");
                    return;
                }

                var game = gameField.GetValue(__instance) as Game;
                if (game == null)
                {
                    HolyModPlugin.Log.LogError("Game instance is null");
                    return;
                }

                var gameData = game.getGameData();
                if (gameData == null)
                {
                    HolyModPlugin.Log.LogError("GameData instance is null");
                    return;
                }

                // Wait a short moment to ensure all coroutines have finished
                GameObject waitObj = new GameObject("ModWaiter");
                waitObj.AddComponent<ModWaiter>().Initialize(gameData);
            }
            catch (Exception ex)
            {
                HolyModPlugin.Log.LogError($"Error in ProcessAllRefData patch: {ex}");
            }
        }
    }

    // Helper class to wait for data processing
    public class ModWaiter : MonoBehaviour
    {
        private GameData gameData;
        private float waitTime = 0f;
        private const float MAX_WAIT_TIME = 5f; // Maximum 5 seconds wait

        public void Initialize(GameData data)
        {
            gameData = data;
            StartCoroutine(WaitForData());
        }

        private IEnumerator WaitForData()
        {
            HolyModPlugin.Log.LogInfo("Waiting for game to initialize...");

            // Wait for game to be loaded and player to start a game
            while (true)
            {
                var currentScene = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
                var refController = GameObject.Find("RefDataController")?.GetComponent<RefDataController>();
                
                // Skip if we're still loading
                if (refController != null && refController.checkShowLoadingScreen())
                {
                    yield return new WaitForSeconds(0.5f);
                    continue;
                }

                // Try to get game instance
                var game = GameObject.Find("Game")?.GetComponent<Game>();
                if (game == null)
                {
                    yield return new WaitForSeconds(0.5f);
                    continue;
                }

                var gameData = game.getGameData();
                if (gameData == null)
                {
                    yield return new WaitForSeconds(0.5f);
                    continue;
                }

                var player = game.getPlayer();
                if (player == null)
                {
                    yield return new WaitForSeconds(0.5f);
                    continue;
                }

                // If we have all required components, inject the weapons
                HolyModPlugin.Log.LogInfo($"Game initialized successfully in scene: {currentScene.name}");
                ModManager.Instance.InjectModdedWeapons(gameData);
                break;
            }

            // Clean up
            Destroy(gameObject);
        }
    }

    [HarmonyPatch(typeof(CommonScreenObject))]
    public class CommonScreenObjectPatches
    {
        [HarmonyPatch("loadTexture")]
        [HarmonyPrefix]
        public static bool LoadTexture_Prefix(string aPath, ref Texture __result)
        {
            try
            {
                if (!aPath.StartsWith("Image/Weapons/"))
                {
                    return true; // Let original method handle non-weapon textures
                }

                string weaponName = Path.GetFileNameWithoutExtension(aPath.Replace("Image/Weapons/", ""));
                string modTexturePath = ModManager.Instance.GetModTexturePath(weaponName);
                
                if (modTexturePath != null && File.Exists(modTexturePath))
                {
                    byte[] fileData = File.ReadAllBytes(modTexturePath);
                    Texture2D texture = new Texture2D(2, 2);
                    texture.LoadImage(fileData);
                    __result = texture;
                    return false; // Skip original method
                }
                
                return true; // Let original method handle vanilla weapons
            }
            catch (Exception ex)
            {
                HolyModPlugin.Log.LogError($"Error loading texture {aPath}: {ex.Message}");
                return true; // Let original method handle on error
            }
        }
    }

    [HarmonyPatch(typeof(DynamicDataController))]
    public class DynamicDataControllerPatches
    {
        [HarmonyPatch("makeDynWeaponList")]
        [HarmonyPostfix]
        public static void MakeDynWeaponList_Postfix(List<DynWeapon> __result)
        {
            if (__result == null) return;

            foreach (var weapon in __result)
            {
                if (ModManager.Instance.IsCustomWeapon(weapon.weaponRefId))
                {
                    weapon.isUnlocked = "Y";
                }
            }
        }
    }

    public class HolyModLoader
    {
        public static void Initialize()
        {
            var harmony = new Harmony("com.holypotatoes.weaponshop.modloader");
            harmony.PatchAll();
        }
    }
}